# -*- ruby encoding: utf-8 -*-

class String
  include Diff::LCS
end
