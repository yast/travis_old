using System;

namespace NGraphite
{
	public enum Encform
	{
		Utf8 = 1,
		Utf16 = 2,
		utf32 = 4
	}
}

