module FastGettext
  VERSION = Version = '0.9.0'
end
