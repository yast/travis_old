require 'mkmf'
create_makefile('name_clash')
