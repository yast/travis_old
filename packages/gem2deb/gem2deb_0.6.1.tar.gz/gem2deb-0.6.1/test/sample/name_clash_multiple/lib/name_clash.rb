require 'name_clash.so'

module NameClash
  ANSWER_42 = 42
end
