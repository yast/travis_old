#include "ruby.h"

void Init_simplemixed() {
  rb_define_module("SimpleMixed");
}
