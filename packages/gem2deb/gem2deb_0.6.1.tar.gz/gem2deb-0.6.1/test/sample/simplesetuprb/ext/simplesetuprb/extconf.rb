require 'mkmf'
create_makefile('simplesetuprb')
