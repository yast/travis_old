require 'mkmf'
create_makefile('simpleextension_with_name_clash')
