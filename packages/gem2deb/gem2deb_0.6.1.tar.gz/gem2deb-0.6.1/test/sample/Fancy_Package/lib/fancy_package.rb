class FancyPackage
end
