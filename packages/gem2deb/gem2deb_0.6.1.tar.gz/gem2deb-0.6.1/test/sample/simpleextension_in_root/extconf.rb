require 'mkmf'
create_makefile('simpleextension_in_root')
