#! /usr/bin/env ruby
require 'example-helper.rb'
example 'ex-calling-methods.body.rb'
