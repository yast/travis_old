#! /usr/bin/env ruby
require 'example-helper.rb'
example 'ex-properties.body.rb'
