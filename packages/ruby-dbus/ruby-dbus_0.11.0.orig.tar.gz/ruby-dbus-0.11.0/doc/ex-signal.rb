#! /usr/bin/env ruby
require 'example-helper.rb'
example 'ex-signal.body.rb'
