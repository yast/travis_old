#include <linux/namei.h>

struct nameidata nd  __attribute__ ((unused)) = {.path={(void *)0}};

