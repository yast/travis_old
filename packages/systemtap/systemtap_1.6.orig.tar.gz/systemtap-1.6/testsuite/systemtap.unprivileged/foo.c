/* Test application */
void bar () {
}

main () {
  bar ();
  return 0;
}
