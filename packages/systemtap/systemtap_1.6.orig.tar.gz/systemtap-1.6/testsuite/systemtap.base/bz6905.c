int main()
{
  int a;

  a = a + 1;
  return 0;
}
