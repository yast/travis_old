module YARD
  VERSION = "0.8.7"
end
