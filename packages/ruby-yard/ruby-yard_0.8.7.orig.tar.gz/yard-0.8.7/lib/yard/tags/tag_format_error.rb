module YARD
  module Tags
    class TagFormatError < Exception
    end
  end
end