require File.join(File.dirname(__FILE__), "..", "spec_helper")

include CodeObjects