def init
  sections :header, [T('docstring')]
end
