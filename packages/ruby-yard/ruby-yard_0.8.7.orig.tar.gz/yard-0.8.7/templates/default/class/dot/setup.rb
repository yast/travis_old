include T('default/module/dot')

def init
  super
  sections.push :superklass
end