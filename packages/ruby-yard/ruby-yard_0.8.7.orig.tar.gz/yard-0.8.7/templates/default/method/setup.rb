def init
  sections :header, [T('method_details')]
end