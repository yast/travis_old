include T('default/module/dot')

def format_path(object)
  ""
end