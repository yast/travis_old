module RSpec
  module Expectations
    # @private
    module Version
      STRING = '2.14.4'
    end
  end
end

