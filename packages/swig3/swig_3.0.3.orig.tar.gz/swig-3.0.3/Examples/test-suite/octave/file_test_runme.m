file_test

file_test.nfile("stdout");

cstdout = file_test.GetStdOut();

file_test.nfile(cstdout);
file_test.nfile_name("test.dat");

