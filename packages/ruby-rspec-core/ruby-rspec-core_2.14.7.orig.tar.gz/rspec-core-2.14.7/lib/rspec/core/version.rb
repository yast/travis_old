module RSpec
  module Core
    module Version
      STRING = '2.14.7'
    end
  end
end

