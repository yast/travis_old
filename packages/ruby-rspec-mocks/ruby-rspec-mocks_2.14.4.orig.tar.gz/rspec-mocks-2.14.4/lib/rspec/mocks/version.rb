module RSpec
  module Mocks
    module Version
      STRING = '2.14.4'
    end
  end
end
