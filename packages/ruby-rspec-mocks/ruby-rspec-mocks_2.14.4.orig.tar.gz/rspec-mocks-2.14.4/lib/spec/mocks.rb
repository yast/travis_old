# For backward compatibility with rspec-1
require 'rspec/mocks'

RSpec.deprecate "require 'spec/mocks'", :replacement => "require 'rspec/mocks'"
