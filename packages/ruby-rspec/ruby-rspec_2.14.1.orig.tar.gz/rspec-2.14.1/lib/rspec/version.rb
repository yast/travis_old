module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '2.14.1'
  end
end
