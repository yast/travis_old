create_makefile("-test-/bug-3662/bug")
