create_makefile("-test-/bug-3571/bug")
